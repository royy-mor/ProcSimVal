#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status

# Check if report type (param1) is provided
if [ -z "$1" ]; then
    echo "Error: Report type not provided."
    echo "Usage: $(basename "$0") report_type"
    exit 1
fi

# Call the first script and filter output using grep
./get_report.sh summary "$1" | grep -E 'Memory Bound|Front-End Bound|Core Bound|Bad Speculation|Retiring|Elapsed Time|CPI Rate|Average CPU Freq'
