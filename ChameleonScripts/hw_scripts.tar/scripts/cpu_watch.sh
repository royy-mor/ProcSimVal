#!/bin/bash

watch -n1 "grep 'MHz' /proc/cpuinfo"
