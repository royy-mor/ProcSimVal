#!/bin/bash

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 
   exit 1
fi

sudo apt-get install cpufrequtils

# Disable intel_pstate by modifying GRUB configuration
echo "Disabling intel_pstate..."
sed -i 's/GRUB_CMDLINE_LINUX="\(.*\)"/GRUB_CMDLINE_LINUX="\1 intel_pstate=disable"/' /etc/default/grub

# Update GRUB
if [ -f /boot/grub2/grub.cfg ]; then
    grub2-mkconfig -o /boot/grub2/grub.cfg
elif [ -f /boot/grub/grub.cfg ]; then
    grub-mkconfig -o /boot/grub/grub.cfg
else
    echo "GRUB configuration file not found! Please update GRUB manually."
    exit 1
fi

echo "GRUB updated. Please reboot your system for changes to take effect."

# Prompt for reboot
echo "Would you like to reboot now? (y/n)"
read -r REBOOT
if [[ "$REBOOT" =~ ^[Yy]$ ]]; then
    reboot
fi

# Load userspace module (after reboot)
modprobe cpufreq_userspace

echo "Setting CPU governor to userspace..."
sudo cpufreq-set --governor userspace

echo "Done!"
