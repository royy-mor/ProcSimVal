#!/bin/bash

# Default values for FREQ and CACHE_WAYS
FREQ=""
CACHE_WAYS=""

# Total available cache ways (adjust for your platform, here it's set to 11)
TOTAL_WAYS=11

# Usage function to show error message and usage instructions
usage() {
    echo "Usage: $0 [--freq <FREQ_MHz>] [--cache <CACHE_WAYS>]"
    echo "  --freq <FREQ_MHz>     Set the CPU frequency (in MHz)."
    echo "  --cache <CACHE_WAYS>   Set the number of cache ways (must not exceed $TOTAL_WAYS)."
    echo "Either --freq or --cache must be provided."
    exit 1
}

# Argument validation
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --freq)
            if [[ "$2" =~ ^[0-9]+$ ]]; then
                FREQ="$2"
                shift 2
            else
                echo "Error: CPU frequency must be a number."
                exit 1
            fi
            ;;
        --cache)
            if [[ "$2" =~ ^[0-9]+$ ]]; then
                CACHE_WAYS="$2"
                if (( CACHE_WAYS > TOTAL_WAYS )); then
                    echo "Error: Cache ways cannot be greater than the total available cache ways ($TOTAL_WAYS)."
                    exit 1
                fi
                shift 2
            else
                echo "Error: Cache ways must be a number."
                exit 1
            fi
            ;;
        *)
            echo "Usage: $0 [--freq <FREQ_MHz>] [--cache <CACHE_WAYS>]"
            exit 1
            ;;
    esac
done

# Ensure either FREQ or CACHE_WAYS is provided
if [ -z "$FREQ" ] && [ -z "$CACHE_WAYS" ]; then
    echo "Error: You must provide either --freq or --cache."
    usage
fi

# Total available cache ways (adjust for your platform)
FULL_MASK=$(( (1 << TOTAL_WAYS) - 1 ))

# If cache ways are provided, calculate the mask
if [ -n "$CACHE_WAYS" ]; then
    CACHE_MASK=$(( (1 << CACHE_WAYS) - 1 ))
    REV_CACHE_MASK=$(( FULL_MASK ^ CACHE_MASK ))

    # Format as hex
    CACHE_HEX_MASK=$(printf "0x%X" "$CACHE_MASK")
    REV_CACHE_HEX_MASK=$(printf "0x%X" "$REV_CACHE_MASK")

    echo "Assigned mask    : $CACHE_HEX_MASK"
    echo "Reverse mask     : $REV_CACHE_HEX_MASK"

    # Reset pqos configuration
    sudo pqos -R
    
    if ((CACHE_WAYS < TOTAL_WAYS)); then
    	# Assign COS 0 to cores 1–47, COS 1 to core 0 (adjust as needed)
    	sudo pqos -a "llc:0=1-47;llc:1=0"

    	# Set cache masks
    	sudo pqos -e "llc:0=$REV_CACHE_HEX_MASK;llc:1=$CACHE_HEX_MASK"
    fi
fi

# If CPU frequency is provided, set the CPU frequency
if [ -n "$FREQ" ]; then
    # Set CPU frequency for core 0 (adjust the core loop for all cores)
    # cpu $(nproc)
    for ((i=0; i<1; i++)); do
        sudo cpufreq-set -c "$i" -f "${FREQ}MHz"
    done
    echo "CPU frequency set to ${FREQ} MHz"
fi

