#!/bin/bash

# fa2024/sp2025 ut senior design procsimval - Ishan Deshpande & Roy Mor

# Improved SPEC CPU benchmark script

# Helper function to show usage
usage() {
    echo "Usage: $0 {build|run} <benchmark_number>"
    echo "Example: $0 build 625  # Builds 625.x264_s benchmark"
    exit 1
}

export SPEC="/home/cc/spec"

# Validate SPEC environment variable
if [ -z "$SPEC" ]; then
    echo "ERROR: SPEC environment variable not set!" >&2
    echo "Please set SPEC to your SPEC CPU installation directory" >&2
    exit 1
fi

cd SPEC
# echo "$PWD"
source shrc

# Get benchmark directory from number
get_benchmark() {
    local bench_num="$1"
    local bench_dir=$(find "$SPEC/benchspec/CPU" -maxdepth 1 -type d -name "${bench_num}.*" -print -quit)
    
    if [ -z "$bench_dir" ]; then
        echo "ERROR: No benchmark found for number $bench_num" >&2
        exit 1
    fi
    
    echo "$(basename "$bench_dir")"
}

# Main script logic
if [ $# -lt 2 ]; then
    usage
fi

ACTION="$1"
BENCH_NUM="$2"
BENCH_NAME=$(get_benchmark "$BENCH_NUM")

case "$ACTION" in
    build)
        echo "Building benchmark: $BENCH_NAME"
        runcpu --config=kayvan_conf --action=runsetup --size=train --tune=base "$BENCH_NAME"
        ;;
    run)
        echo "Running benchmark: $BENCH_NAME"
        RUN_DIR=$(find "$SPEC/benchspec/CPU/$BENCH_NAME/run" -type d -name "*_train*" -print -quit)
        
        if [ -z "$RUN_DIR" ]; then
            echo "ERROR: No run directory found for $BENCH_NAME" >&2
            exit 1
        fi
        
        specinvoke -C "$RUN_DIR/speccmds.cmd"
        ;;
    *)
        usage
        ;;
esac
