#!/bin/bash

for ((i=0;i<$(nproc);i++)); do
    sudo cpufreq-set -c $i -g userspace
done
