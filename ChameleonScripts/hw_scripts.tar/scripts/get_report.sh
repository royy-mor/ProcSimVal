#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status

# Define a local variable for the base directory
base="/home/cc/results/"

# Check if report type (param1) is provided
if [ -z "$1" ]; then
    echo "Error: Report type not provided."
    echo "Usage: $(basename "$0") report_type result_folder"
    exit 1
fi

# Check if result folder (param2) is provided
if [ -z "$2" ]; then
    echo "Error: Result folder not provided."
    echo "Usage: $(basename "$0") report_type result_folder"
    exit 1
fi

report_type="$1"
result_folder="$2"

# Call VTune with the provided parameters
"/opt/intel/oneapi/vtune/latest/bin64/vtune" -report "$report_type" -result-dir="${base}${result_folder}"
